#include "playlistmanager.h"

PlaylistManager::PlaylistManager(QObject *parent) : QObject(parent), currentSongIndex(-1), mediaPlayer(new QMediaPlayer(this))
{
}

void PlaylistManager::createPlaylist(const QString &name)
{
    if (!playlists.contains(name)) {
        playlists[name] = QStringList();
    }
}

void PlaylistManager::deletePlaylist(const QString &name)
{
    if (playlists.contains(name)) {
        playlists.remove(name);
    }
}

void PlaylistManager::addSongToPlaylist(const QString &playlistName, const QString &songPath)
{
    if (playlists.contains(playlistName)) {
        playlists[playlistName].append(songPath);
    }
}

void PlaylistManager::removeSongFromPlaylist(const QString &playlistName, const QString &songPath)
{
    if (playlists.contains(playlistName)) {
        playlists[playlistName].removeAll(songPath);
    }
}

QStringList PlaylistManager::getPlaylists() const
{
    return playlists.keys();
}

QStringList PlaylistManager::getSongs(const QString &playlistName) const
{
    return playlists.value(playlistName);
}

QString PlaylistManager::getCurrentSongPath() const
{
    if (currentPlaylist.isEmpty() || currentSongIndex < 0 || currentSongIndex >= playlists[currentPlaylist].size()) {
        return QString();
    }
    return playlists[currentPlaylist][currentSongIndex];
}

void PlaylistManager::playNext()
{
    if (!currentPlaylist.isEmpty() && currentSongIndex + 1 < playlists[currentPlaylist].size()) {
        currentSongIndex++;
        mediaPlayer->setSource(QUrl::fromLocalFile(playlists[currentPlaylist][currentSongIndex]));
        mediaPlayer->play();
        emit songChanged(playlists[currentPlaylist][currentSongIndex]);
    }
}

void PlaylistManager::playPrevious()
{
    if (!currentPlaylist.isEmpty() && currentSongIndex > 0) {
        currentSongIndex--;
        mediaPlayer->setSource(QUrl::fromLocalFile(playlists[currentPlaylist][currentSongIndex]));
        mediaPlayer->play();
        emit songChanged(playlists[currentPlaylist][currentSongIndex]);
    }
}

void PlaylistManager::play()
{
    if (!currentPlaylist.isEmpty() && currentSongIndex >= 0 && currentSongIndex < playlists[currentPlaylist].size()) {
        mediaPlayer->setSource(QUrl::fromLocalFile(playlists[currentPlaylist][currentSongIndex]));
        mediaPlayer->play();
        emit songChanged(playlists[currentPlaylist][currentSongIndex]);
    }
}

void PlaylistManager::pause()
{
    mediaPlayer->pause();
}

void PlaylistManager::savePlaylists(const QString &filename) const
{
    QJsonObject json;
    for (auto it = playlists.constBegin(); it != playlists.constEnd(); ++it) {
        QJsonArray songArray;
        for (const QString &song : it.value()) {
            songArray.append(song);
        }
        json[it.key()] = songArray;
    }
    QJsonDocument doc(json);
    QFile file(filename);
    if (file.open(QIODevice::WriteOnly)) {
        file.write(doc.toJson());
        file.close();
    }
}

void PlaylistManager::loadPlaylists(const QString &filename)
{
    QFile file(filename);
    if (file.open(QIODevice::ReadOnly)) {
        QByteArray data = file.readAll();
        file.close();
        QJsonDocument doc(QJsonDocument::fromJson(data));
        QJsonObject json = doc.object();
        playlists.clear();
        for (auto it = json.begin(); it != json.end(); ++it) {
            QJsonArray songArray = it.value().toArray();
            QStringList songList;
            for (const QJsonValue &value : songArray) {
                songList.append(value.toString());
            }
            playlists[it.key()] = songList;
        }
    }
}
