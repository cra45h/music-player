#ifndef PLAYLISTMANAGER_H
#define PLAYLISTMANAGER_H

#include <QObject>
#include <QMap>
#include <QString>
#include <QStringList>
#include <QMediaPlayer>
#include <QJsonObject>
#include <QJsonArray>
#include <QJsonDocument>
#include <QFile>

class PlaylistManager : public QObject
{
    Q_OBJECT

public:
    explicit PlaylistManager(QObject *parent = nullptr);

    void createPlaylist(const QString &name);
    void deletePlaylist(const QString &name);
    void addSongToPlaylist(const QString &playlistName, const QString &songPath);
    void removeSongFromPlaylist(const QString &playlistName, const QString &songPath);

    QStringList getPlaylists() const;
    QStringList getSongs(const QString &playlistName) const;
    QString getCurrentSongPath() const;

    void savePlaylists(const QString &filename) const;
    void loadPlaylists(const QString &filename);

public slots:
    void playNext();
    void playPrevious();
    void play();
    void pause();

signals:
    void songChanged(const QString &songPath);

private:
    QMap<QString, QStringList> playlists;
    QString currentPlaylist;
    int currentSongIndex;
    QMediaPlayer *mediaPlayer;
};

#endif // PLAYLISTMANAGER_H
