#include "mainwindow.h"
#include "ui_mainwindow.h"
/*#include <QInputDialog>
#include <QFileDialog>
#include <QStyle>
#include <QMessageBox>
#include <QCloseEvent>*/

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , player(new QMediaPlayer(this))
    , playlistManager(new PlaylistManager(this))
    , isPlaying(false)
{
    ui->setupUi(this);
    setWindowTitle("UmusiK");
    audioOutput = new QAudioOutput;
    player->setAudioOutput(audioOutput);
    ui->playButton->setIcon(style()->standardIcon(QStyle::SP_MediaPlay));
    ui->nextButton->setIcon(style()->standardIcon(QStyle::SP_MediaSkipForward));
    ui->previousButton->setIcon(style()->standardIcon(QStyle::SP_MediaSkipBackward));
    connect(ui->positionSlider, &QSlider::valueChanged, this, &MainWindow::on_positionSlider_valueChanged);
    connect(player, &QMediaPlayer::positionChanged, this, &MainWindow::on_positionChanged);
    connect(player, &QMediaPlayer::durationChanged, this, &MainWindow::on_durationChanged);
    connect(ui->addPlaylistButton, &QPushButton::clicked, this, &MainWindow::createPlaylist);
    connect(ui->removePlaylistButton, &QPushButton::clicked, this, &MainWindow::deletePlaylist);
    connect(ui->previousButton, &QPushButton::clicked, this, &MainWindow::on_previousButton_clicked);
    connect(ui->nextButton, &QPushButton::clicked, this, &MainWindow::on_nextButton_clicked);

    connect(ui->addSongs, &QPushButton::clicked, this, &MainWindow::addSong);
    connect(ui->removeSongs, &QPushButton::clicked, this, &MainWindow::removeSong);
    connect(ui->playlistView, &QListView::clicked, this, &MainWindow::updateSongs);
    connect(ui->songlistView, &QListView::doubleClicked, this, &MainWindow::playSong);
    connect(ui->playButton, &QPushButton::clicked, this, &MainWindow::playPauseSong);

    connect(player, &QMediaPlayer::mediaStatusChanged, this, &MainWindow::onSongEnded);


    playlistManager->loadPlaylists("playlists.json");
    updatePlaylists();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::closeEvent(QCloseEvent *event)
{
    playlistManager->savePlaylists("playlists.json");
    event->accept();
}

void MainWindow::createPlaylist()
{
    bool ok;
    QString name = QInputDialog::getText(this, tr("Create Playlist"),
                                         tr("Playlist name:"), QLineEdit::Normal,
                                         "", &ok);
    if (ok && !name.isEmpty()) {
        playlistManager->createPlaylist(name);
        updatePlaylists();
    }
}

void MainWindow::deletePlaylist()
{
    QString name = ui->playlistView->currentIndex().data().toString();
    if (!name.isEmpty()) {
        playlistManager->deletePlaylist(name);
        updatePlaylists();
        ui->songlistView->setModel(nullptr); // Clear song view
    }
}

void MainWindow::addSong()
{
    QString name = ui->playlistView->currentIndex().data().toString();
    if (!name.isEmpty()) {
        QStringList files = QFileDialog::getOpenFileNames(this, tr("Select Music Files"), "", tr("Music Files (*.mp3 *.wav *.flac)"));
        for (const QString &file : files) {
            playlistManager->addSongToPlaylist(name, file);
        }
        updateSongs();
    }
}

void MainWindow::removeSong()
{
    QString playlistName = ui->playlistView->currentIndex().data().toString();
    QString songName = ui->songlistView->currentIndex().data().toString();
    if (!playlistName.isEmpty() && !songName.isEmpty()) {
        QString songPath;
        for (const QString &path : playlistManager->getSongs(playlistName)) {
            if (path.endsWith(songName)) {
                songPath = path;
                break;
            }
        }
        if (!songPath.isEmpty()) {
            playlistManager->removeSongFromPlaylist(playlistName, songPath);
            updateSongs();
        }
    }
}

void MainWindow::playPauseSong()
{
    if (isPlaying) {
        player->pause();
        ui->playButton->setIcon(style()->standardIcon(QStyle::SP_MediaPlay));
    } else {
        if (player->source().isEmpty()) {
            playSong(); // Play the selected song if none is currently playing
        } else {
            player->play();
        }
        ui->playButton->setIcon(style()->standardIcon(QStyle::SP_MediaPause));
    }
    isPlaying = !isPlaying;
}

void MainWindow::playSong()
{
    QString playlistName = ui->playlistView->currentIndex().data().toString();
    QString songName = ui->songlistView->currentIndex().data().toString();
    if (!playlistName.isEmpty() && !songName.isEmpty()) {
        QString songPath;
        for (const QString &path : playlistManager->getSongs(playlistName)) {
            if (path.endsWith(songName)) {
                songPath = path;
                break;
            }
        }
        if (!songPath.isEmpty()) {
            player->setSource(QUrl::fromLocalFile(songPath));
            player->play();
            ui->playButton->setIcon(style()->standardIcon(QStyle::SP_MediaPause));
            isPlaying = true;
        }
    }
}
void MainWindow::on_volumeSlider_valueChanged(int value)
{
    audioOutput->setVolume(value / 100.0);
}

void MainWindow::on_positionSlider_valueChanged(int value)
{
    // Seek to the position in the song
    if (qAbs(player->position() - value) > 99) {
        player->setPosition(value);
    }
}

void MainWindow::on_positionChanged(qint64 position)
{
    // Update the song slider position
    ui->positionSlider->setValue(static_cast<int>(position));
}

void MainWindow::on_durationChanged(qint64 duration)
{
    // Set the song slider range
    ui->positionSlider->setRange(0, static_cast<int>(duration));
}
void MainWindow::on_nextButton_clicked()
{
    QString playlistName = ui->playlistView->currentIndex().data().toString();
    if (!playlistName.isEmpty()) {
        int currentIndex = ui->songlistView->currentIndex().row();
        int nextIndex = currentIndex + 1;
        if (nextIndex < ui->songlistView->model()->rowCount()) {
            QModelIndex nextModelIndex = ui->songlistView->model()->index(nextIndex, 0);
            ui->songlistView->setCurrentIndex(nextModelIndex);
            playSong();
        }
    }
}
void MainWindow::on_previousButton_clicked()
{
    QString playlistName = ui->playlistView->currentIndex().data().toString();
    if (!playlistName.isEmpty()) {
        int currentIndex = ui->songlistView->currentIndex().row();
        int nextIndex = currentIndex - 1;
        if (nextIndex < ui->songlistView->model()->rowCount()) {
            QModelIndex nextModelIndex = ui->songlistView->model()->index(nextIndex, 0);
            ui->songlistView->setCurrentIndex(nextModelIndex);
            playSong();
        }
    }
}

void MainWindow::onSongEnded()
{
    if (player->mediaStatus() == QMediaPlayer::EndOfMedia) {
        playlistManager->playNext();
        QString nextSong = playlistManager->getCurrentSongPath();
        if (!nextSong.isEmpty()) {
            player->setSource(QUrl::fromLocalFile(nextSong));
            player->play();
        }
    }
}

void MainWindow::updatePlaylists()
{
    QStringList playlists = playlistManager->getPlaylists();
    QStringListModel *model = new QStringListModel(playlists, this);

    ui->playlistView->setModel(model);
}

void MainWindow::updateSongs()
{
    QString playlistName = ui->playlistView->currentIndex().data().toString();
    if (!playlistName.isEmpty()) {
        QStringList songs;
        for (const QString &path : playlistManager->getSongs(playlistName)) {
            songs.append(QFileInfo(path).fileName());
        }
        QStringListModel *model = new QStringListModel(songs, this);
        ui->songlistView->setModel(model);
    }
}
